// js/perfil.js

document.addEventListener('DOMContentLoaded', async function() {
    const token = localStorage.getItem('authToken');

    // Se não houver token salvo, redireciona para tela de login
    if (!token) {
        window.location.href = 'login.html';
        return;
    }

    try {
        // Busca perfil atualizado da API Java enviando o token Bearer
        const response = await fetch(`${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.PERFIL}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error('Sessão expirada. Faça login novamente.');
        }

        const user = await response.json();
        renderUserProfile(user);

    } catch (error) {
        // Caso a API não esteja rodando ainda, recupera os dados do localStorage temporariamente
        const localUser = JSON.parse(localStorage.getItem('userData') || '{}');
        if (localUser.nome || localUser.email) {
            renderUserProfile(localUser);
        } else {
            alert('Sessão inválida. Redirecionando para login.');
            localStorage.clear();
            window.location.href = 'login.html';
        }
    }
});

function renderUserProfile(user) {
    const nome = user.nome || user.name || 'Usuário';
    const email = user.email || 'email@naoinformado.com';

    document.getElementById('userName').innerText = nome;
    document.getElementById('userEmail').innerText = email;
    document.getElementById('userInitial').innerText = nome.charAt(0).toUpperCase();
}

// Botão de Logout
document.getElementById('logoutBtn').addEventListener('click', function() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('userData');
    window.location.href = 'login.html';
});
